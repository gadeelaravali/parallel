package com.capgemini.flp.dao;

import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

import javax.management.Query;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.hibernate.annotations.Sort;
import org.jboss.logging.Param;
import org.springframework.stereotype.Repository;

import com.capgemini.flp.dto.AdminProduct;
import com.capgemini.flp.exception.ProductNotFoundException;


@Repository
public class AdminProductDaoImpl  {


	@PersistenceContext
	EntityManager entityManager;
	
	public List<AdminProduct> getProduct() throws ProductNotFoundException {
		List<AdminProduct> list = null;
		try{
			TypedQuery<AdminProduct> query=entityManager.createQuery("from Admin_Product",AdminProduct.class);

		}catch(Exception e){
			throw new ProductNotFoundException(e.getMessage());
		}
		return list;
	}
	public List<AdminProduct> sortfromhightolow(List<AdminProduct> products) throws ProductNotFoundException
	{		
		List<AdminProduct> product = entityManager.createNamedQuery("SELECT * FROM AdminProducts ORDER BY product_price DESC", AdminProduct.class).getResultList() ;   
		
		return product;
		
	}
	
	public List<AdminProduct> sortfromlowtohigh(List<AdminProduct> products) throws ProductNotFoundException
	{		
		List<AdminProduct> product = entityManager.createNamedQuery("SELECT * FROM AdminProducts ORDER BY product_price ASC", AdminProduct.class).getResultList() ;   
		
		return product;
		
	}
	
}
