package com.capgemini.flp.dao;

import java.util.List;

import com.capgemini.flp.dto.AdminProduct;
import com.capgemini.flp.exception.ProductNotFoundException;

public interface AdminProductDao {
	List<AdminProduct> getProducts() throws ProductNotFoundException;
	public List<AdminProduct> sortfromhightolow(List<AdminProduct> products) throws ProductNotFoundException;
}
