package com.capgemini.flp.exception;

public class ProductNotFoundException extends Exception{

	public ProductNotFoundException(String s)
	{
		super(s);
	}
}
