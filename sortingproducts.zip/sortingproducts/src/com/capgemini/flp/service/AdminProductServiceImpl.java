package com.capgemini.flp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.capgemini.flp.dao.AdminProductDao;
import com.capgemini.flp.dto.AdminProduct;
import com.capgemini.flp.exception.ProductNotFoundException;

public class AdminProductServiceImpl {


	@Autowired
    AdminProductDao adminProductDao;
	public List<AdminProduct> getProducts() throws ProductNotFoundException
	{
		return adminProductDao.getProducts();
	}

	public List<AdminProduct> sortfromhightolow(List<AdminProduct> products) throws ProductNotFoundException
	{
		return adminProductDao.getProducts();
	}
}
