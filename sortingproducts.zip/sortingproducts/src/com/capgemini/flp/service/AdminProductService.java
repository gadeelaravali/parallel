package com.capgemini.flp.service;

import java.util.List;

import com.capgemini.flp.dto.AdminProduct;
import com.capgemini.flp.exception.ProductNotFoundException;

public interface AdminProductService {

	List<AdminProduct> getProducts() throws ProductNotFoundException;

	public List<AdminProduct> sortfromhightolow(List<AdminProduct> products) throws ProductNotFoundException;
	
}
