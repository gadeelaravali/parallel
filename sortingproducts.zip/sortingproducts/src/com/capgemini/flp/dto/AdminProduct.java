package com.capgemini.flp.dto;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.Table;
@Entity
@Table(name = "admin_products")
public class AdminProduct implements Serializable,Comparable<AdminProduct>{ 
    private static final long serialVersionUID = 1L;
    private int product_Id;
    private String product_Name;
    private String product_Category;
    private String product_Description;
    private double product_price;
    private String product_image;
    private int product_quality;
    private String seller_email_Id;
    private String product_Discount;
    private int timeForDiscount;
    private String product_promo;
    private int timeForPromo;
    private int numberOfProductSold;
    private int numberOfProductExchanged;
    private double sellingAmount;
    private double exchangeAmount;
	public int getProduct_Id() {
		return product_Id;
	}
	public void setProduct_Id(int product_Id) {
		this.product_Id = product_Id;
	}
	public String getProduct_Name() {
		return product_Name;
	}

	public String getProduct_Category() {
		return product_Category;
	}
	public void setProduct_Category(String product_Category) {
		this.product_Category = product_Category;
	}
	public String getProduct_Description() {
		return product_Description;
	}
	public void setProduct_Description(String product_Description) {
		this.product_Description = product_Description;
	}
	public double getProduct_price() {
		return product_price;
	}
	public void setProduct_price(double product_price) {
		this.product_price = product_price;
	}
	public String getProduct_image() {
		return product_image;
	}
	public void setProduct_image(String product_image) {
		this.product_image = product_image;
	}
	public int getProduct_quality() {
		return product_quality;
	}
	public void setProduct_quality(int product_quality) {
		this.product_quality = product_quality;
	}
	public String getSeller_email_Id() {
		return seller_email_Id;
	}
	public void setSeller_email_Id(String seller_email_Id) {
		this.seller_email_Id = seller_email_Id;
	}
	public String getProduct_Discount() {
		return product_Discount;
	}
	public void setProduct_Discount(String product_Discount) {
		this.product_Discount = product_Discount;
	}
	public int getTimeForDiscount() {
		return timeForDiscount;
	}
	public void setTimeForDiscount(int timeForDiscount) {
		this.timeForDiscount = timeForDiscount;
	}
	public String getProduct_promo() {
		return product_promo;
	}
	public void setProduct_promo(String product_promo) {
		this.product_promo = product_promo;
	}
	public int getTimeForPromo() {
		return timeForPromo;
	}
	public void setTimeForPromo(int timeForPromo) {
		this.timeForPromo = timeForPromo;
	}
	public int getNumberOfProductSold() {
		return numberOfProductSold;
	}
	public void setNumberOfProductSold(int numberOfProductSold) {
		this.numberOfProductSold = numberOfProductSold;
	}
	public int getNumberOfProductExchanged() {
		return numberOfProductExchanged;
	}
	public void setNumberOfProductExchanged(int numberOfProductExchanged) {
		this.numberOfProductExchanged = numberOfProductExchanged;
	}
	public double getSellingAmount() {
		return sellingAmount;
	}
	public void setSellingAmount(double sellingAmount) {
		this.sellingAmount = sellingAmount;
	}
	public double getExchangeAmount() {
		return exchangeAmount;
	}
	public void setExchangeAmount(double exchangeAmount) {
		this.exchangeAmount = exchangeAmount;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public AdminProduct(int product_Id, String product_Name, String product_Category, String product_Description,
			double product_price, String product_image, int product_quality, String seller_email_Id,
			String product_Discount, int timeForDiscount, String product_promo, int timeForPromo,
			int numberOfProductSold, int numberOfProductExchanged, double sellingAmount, double exchangeAmount) {
		super();
		this.product_Id = product_Id;
		this.product_Name = product_Name;
		this.product_Category = product_Category;
		this.product_Description = product_Description;
		this.product_price = product_price;
		this.product_image = product_image;
		this.product_quality = product_quality;
		this.seller_email_Id = seller_email_Id;
		this.product_Discount = product_Discount;
		this.timeForDiscount = timeForDiscount;
		this.product_promo = product_promo;
		this.timeForPromo = timeForPromo;
		this.numberOfProductSold = numberOfProductSold;
		this.numberOfProductExchanged = numberOfProductExchanged;
		this.sellingAmount = sellingAmount;
		this.exchangeAmount = exchangeAmount;
	}
	@Override
	public int compareTo(AdminProduct o) {
return new Double(this.product_price).compareTo(new Double(o.product_price));
	}
	@Override
	public String toString() {
		return "AdminProduct [product_Id=" + product_Id + ", product_Name=" + product_Name + ", product_Category="
				+ product_Category + ", product_Description=" + product_Description + ", product_price=" + product_price
				+ ", product_image=" + product_image + ", product_quality=" + product_quality + ", seller_email_Id="
				+ seller_email_Id + ", product_Discount=" + product_Discount + ", timeForDiscount=" + timeForDiscount
				+ ", product_promo=" + product_promo + ", timeForPromo=" + timeForPromo + ", numberOfProductSold="
				+ numberOfProductSold + ", numberOfProductExchanged=" + numberOfProductExchanged + ", sellingAmount="
				+ sellingAmount + ", exchangeAmount=" + exchangeAmount + "]";
	}
  

}
	