package com.capgemini.flp.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.flp.dto.AdminProduct;
import com.capgemini.flp.exception.ProductNotFoundException;
import com.capgemini.flp.service.AdminProductService;

public class AdminProductController {

	
	@Controller
	public class EmployeeController {
		
		@Autowired
		AdminProductService adminProductService;
		
		@RequestMapping("/")
		public ModelAndView showIndex(){
			ModelAndView mv=new ModelAndView("index");
			try {
				List<AdminProduct> products=adminProductService.getProducts();
				adminProductService.sortfromhightolow(products);
				mv.addObject("product",products);
			} catch (ProductNotFoundException e) {
				e.getMessage();
			}
			return mv;
		}
	}
}
	

