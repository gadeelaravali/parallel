package com.capg.cms.exception;
public class CustomerNotFoundException extends Exception{


public CustomerNotFoundException (String getMessage)
{
	super(getMessage);
}
	

}
