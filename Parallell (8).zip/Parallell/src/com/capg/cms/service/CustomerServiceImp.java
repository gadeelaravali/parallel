package com.capg.cms.service;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capg.cms.beans.Customer;
import com.capg.cms.beans.Transaction;
import com.capg.cms.dao.CustomerDAOImp;
import com.capg.cms.exception.CustomerNotFoundException;
public class CustomerServiceImp implements ICustomerService {
	CustomerDAOImp dao = new CustomerDAOImp();
	@Override
	public boolean addCustomer(Customer c) throws CustomerNotFoundException {
		return dao.addCustomer(c);
	}
@Override
	public double displayCustomer(int accno,int pinno) throws CustomerNotFoundException {
	return dao.displayCustomer(accno,pinno);
	}

	public double withDraw(Customer c1,double wd) throws CustomerNotFoundException
	{
		return dao.withDraw(c1,wd);
		
	}
	public double depositAmt(double da,Customer c,int accno,int pin) throws CustomerNotFoundException
	{
		return dao.depositAmt(da,c,accno,pin);
		
	}
	
	public List<Transaction> printTransactions(int cid, int pinno)throws CustomerNotFoundException {
		// TODO Auto-generated method stub
		return dao.printTransactions(cid, pinno);
	}

	public boolean validateAccno(int accno) throws CustomerNotFoundException {
		// TODO Auto-generated method stub
		
		return dao.validateAccno(accno);
	}
	public boolean validatePinno(int accno,int pinno) throws CustomerNotFoundException {
		// TODO Auto-generated method stub
		
		return dao.validatePinno(accno,pinno);
	}
	public Customer displayCust(int accno) {
		return dao.displayCust(accno);
	}
	public boolean fundTransfer(Customer c,Customer b,double at,int accno1,int accno2,int pinno) throws CustomerNotFoundException
	{
		return dao.fundTransfer(c,b,at,accno1,accno2,pinno);
	}

public boolean validatePhno(String mobileno)
{
	boolean flag = false;
    Pattern pattern = Pattern.compile("^(0/91)?[7-9][0-9]{9}");
    Matcher matcher = pattern.matcher(mobileno);
    if(matcher.matches())
    {
        flag=true;
    }
	return flag;	
}
public boolean validateName(String name)
{
	boolean flag = false;
	if(name.matches("^[A-Za-z\\s]+$"))
	{
		flag = true;
	}
	return flag;	
}
public boolean validateAge(int age)
{
	boolean flag = false;
	if(age>18 && age<100)
	{
		flag = true;
	}
	return flag;	
}
public boolean validatePan(String panno)
{
	boolean flag = false;
	if(panno.matches("^[A-Za-z]{5}[0-9]{4}[A-Za-z]{1}"))
	{
		flag = true;
	}
	return flag;	
}



}



 
