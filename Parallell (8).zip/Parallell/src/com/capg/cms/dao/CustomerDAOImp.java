package com.capg.cms.dao;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceException;

import com.capg.cms.beans.Customer;
import com.capg.cms.exception.CustomerNotFoundException;
import com.capg.cms.beans.Transaction;
public class CustomerDAOImp implements ICustomerDAO {
	EntityManagerFactory factory = Persistence.createEntityManagerFactory("Parallell");
	Transaction transaction=new Transaction();
	DateFormat dateFormat=new SimpleDateFormat("dd/MM/yyyy hh.mm aa");
	Date date =new Date();
	@Override
	public boolean addCustomer(Customer cus) throws CustomerNotFoundException{
		EntityManager em=factory.createEntityManager();
		try{

			em.getTransaction().begin();
			em.persist(cus);
			em.getTransaction().commit();
			return em.contains(cus);
		}catch(PersistenceException e) {
			throw new CustomerNotFoundException(e.getMessage());
		}finally {    
			em.close();
		}
	}
	@Override
	public boolean validateAccno(int id1) throws CustomerNotFoundException {
		EntityManager em=factory.createEntityManager();
		boolean flag=false;
		try{
			Customer customer=em.find(Customer.class, id1);
			if(customer==null)
			{
				flag=false;
			}else if(customer.getAccno()==id1){
				flag=true;
			}
			return flag;
		}catch(PersistenceException e) {
			throw new CustomerNotFoundException(e.getMessage());
		}finally {
			em.close();
		}
	}
	@Override
	public boolean validatePinno(int id1,int id2) throws CustomerNotFoundException {

		boolean flag=false;

		EntityManager em=factory.createEntityManager();
		try{
		
			Customer customer=em.find(Customer.class,id1);
			if(customer.getPin()==id2){
				flag=true;
			}
			return flag;
		}catch(PersistenceException e) {
			throw new CustomerNotFoundException(e.getMessage());
		}finally {
			em.close();
		}
	}
	public double displayCustomer(int id1,int id2) throws CustomerNotFoundException {	

		double a=0.0;
				EntityManager em=factory.createEntityManager();
		try{

			Customer customer=em.find(Customer.class,id1);
			if(customer.getAccno()==id1&&customer.getPin()==id2)
				a=customer.getAmt();			
			return a;
		}catch(PersistenceException e) {
			throw new CustomerNotFoundException(e.getMessage());
		}finally {
			em.close();
		}

	}
	public double withDraw(Customer c1,double withdrawAmount) throws CustomerNotFoundException {

		EntityManager em=factory.createEntityManager();
		if(c1.getAmt()>withdrawAmount && withdrawAmount>0){
			try{
				em.getTransaction().begin();
				double balance=0.0;
				balance=c1.getAmt()-withdrawAmount;
			transaction.setTransaction("  "+dateFormat.format(date)+"    withdraw       "+withdrawAmount+"       "+balance);				
				c1.setAmt(balance);
				c1.addTransaction(transaction);
				em.merge(c1);
				em.getTransaction().commit();	
				return c1.getAmt();
			}catch(PersistenceException e) {
				throw new CustomerNotFoundException(e.getMessage());
			}finally {
				em.close();
			}
		}
		return c1.getAmt();

	}
	public double depositAmt(double depositAmount,Customer c,int accno,int pin) throws CustomerNotFoundException {
	
		EntityManager em=factory.createEntityManager();
		try{
			if(c.getAccno()==accno&&c.getPin()==pin){
				if(depositAmount>0)
				{
				em.getTransaction().begin();
				double balance=0;
				balance=c.getAmt()+depositAmount;
				transaction.setTransaction("  "+dateFormat.format(date)+"    deposit     "+depositAmount+"         "+balance);
				c.setAmt(balance);	
				c.addTransaction(transaction);
				em.merge(c);
				em.getTransaction().commit();	
				}
				return c.getAmt();	
				
			}else
			{
				return 0;
			}
		
		
		}catch(PersistenceException e) {
			throw new CustomerNotFoundException(e.getMessage());
		}finally {
			em.close();
		}
	}
	@Override
	public List<Transaction> printTransactions(int cid,int pin) throws CustomerNotFoundException{

		EntityManager em=factory.createEntityManager();
		try{
			Customer c=em.find(Customer.class, cid);
			if(c.getAccno()==cid&&c.getPin()==pin){
				List<Transaction> TransList=c.getTransactions();
				return TransList;
			}
			return null;
		}catch(PersistenceException e) {
			throw new CustomerNotFoundException("no transactions done"+e.getMessage());
		}finally {
			em.close();
		}
	}

	public Customer displayCust(int accno) {
		Customer customer=null;
		EntityManager em=factory.createEntityManager();
		try{
			customer=em.find(Customer.class,accno);
			return customer;
		}
		catch(PersistenceException e) {
			try {
				throw new CustomerNotFoundException(e.getMessage());
			} catch (CustomerNotFoundException e1) {
			}
		}finally {
			em.close();
		}
		return customer;
	}
	public boolean fundTransfer(Customer c,Customer b,double at,int accno1,int accno2,int pinno) throws CustomerNotFoundException
	{
		boolean flag=false;
		if(c.getAccno()==accno1&&c.getPin()==pinno){
			if(b.getAccno()==accno2){
				if(c.getAmt()>at){
					EntityManager em=factory.createEntityManager();
					try{
						em.getTransaction().begin();
						double balance=c.getAmt();
						balance=balance-at;					
						transaction.setTransaction("  "+dateFormat.format(date)+"   fundTranfer     "+at+"         "+balance);			
						c.setAmt(balance);
						c.addTransaction(transaction);
						em.merge(c);
						double balance1=b.getAmt();
						balance1=balance1+at;
						transaction.setTransaction("  "+dateFormat.format(date)+"   fundTranfer     "+at+"         "+balance1);				
						b.setAmt(balance1);
						b.addTransaction(transaction);
						em.merge(b);
						em.getTransaction().commit();	
						flag=true;
					}catch(PersistenceException e) {
						throw new CustomerNotFoundException(e.getMessage());
					}finally {
						em.close();
					}
				}
			}
		}
		return flag;
	}
}

