package com.capg.cms.dao;

import java.util.List;

import com.capg.cms.beans.Customer;
import com.capg.cms.beans.Transaction;
import com.capg.cms.exception.CustomerNotFoundException;

public interface ICustomerDAO {
	   public boolean addCustomer(Customer c) throws CustomerNotFoundException;
	  public double displayCustomer(int accno,int pinno) throws CustomerNotFoundException;
	  public Customer displayCust(int accno);
public	double withDraw(Customer c1,double withdrawAmount) throws CustomerNotFoundException;
public double depositAmt(double depositAmount,Customer c,int accno,int pin) throws CustomerNotFoundException;

public boolean validateAccno(int accno) throws CustomerNotFoundException;
//public boolean validatePinno(int pinno) throws CustomerNotFound;
public boolean fundTransfer(Customer c,Customer b,double amt,int accno1,int accno2,int pinno) throws CustomerNotFoundException;
public List<Transaction> printTransactions(int cid,int pinno) throws CustomerNotFoundException;
boolean validatePinno(int id1, int id2) throws CustomerNotFoundException;
}
