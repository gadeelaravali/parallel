package com.capg.cms.ui;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Scanner;

import com.capg.cms.beans.Customer;
import com.capg.cms.beans.Transaction;
import com.capg.cms.exception.CustomerNotFoundException;
import com.capg.cms.service.CustomerServiceImp;

public class Client {
	public static void main(String[] args) throws CustomerNotFoundException,NullPointerException,InputMismatchException {
		CustomerServiceImp service = new CustomerServiceImp();

		while (true) {
			System.out.println("WELCOME TO CUSTOMER MANAGMENT");
			System.out.println("-------------------------------------");
			System.out.println("1.ADD CUSTOMER");
			System.out.println("2.SHOW BALANCE");
			System.out.println("3.DEPOSIT AMOUNT");
			System.out.println("4.WITHDRAW AMOUNT");
			System.out.println("5.FUND TRANSFER");
			System.out.println("6.PRINT TRANSACTIONS");
			System.out.println("7.EXIT");
			System.out.println("-------------------------------------");
			Scanner sc = new Scanner(System.in);
			int choice = sc.nextInt();
			switch (choice) {
			case 1:		
				Customer bean = new Customer(null,null,0,null,0,null);
				boolean validname=false;
				boolean validphno = false;
				boolean validage = false;	
				boolean validpan = false;
				do{					
					System.out.println("ENTER CUSTOMER  NAME");
					String cname = sc.next();
					if(service.validateName(cname))
					{bean.setCname(cname);
					validname=true;
					}
					else
						System.out.println("PLEASE ENTER CORRECT NAME");
				}while(!validname);
				do				
				{
					System.out.println("ENTER CUSTOMER MOBILENO");
				
					try{
					String mobileno = sc.next();
					if(service.validatePhno(mobileno))					
					{	bean.setMobileno(mobileno);
					validphno=true;
					}
					
					}
					catch(InputMismatchException e1)
					{
						System.out.println("ENTER VALID MOBILE NUMBER");
					}	
					
				}while(!validphno);
				do
				{
					System.out.println("ENTER CUSTOMER PANNO");
					String panno = sc.next().toUpperCase();
					if(service.validatePan(panno))
					{bean.setPanno(panno);
					validpan=true;
					}else
						System.out.println("PLEASE ENTER CORRECT PAN NO");
				}while(!validpan);				
				 int age=0;
				do
				{  
					System.out.println("ENTER CUSTOMER AGE");	
					Scanner sc1 = new Scanner(System.in);
					 try{
					 age = sc1.nextInt();
					
					 if(service.validateAge(age))
						{
							bean.setAge(age);
							validage=true;
						}else
						{
							System.out.println("AGE SHOULD BE BETWEEN 18 to 100");
						}
					 }
					/* else
					 {
						 try{
						 throw new InputMismatchException("PLEASE ENTER VALID FORMAT FOR AGE");
					 }	*/				 
					catch(InputMismatchException e1)
					{
						System.out.println("AGE SHOULD BE IN NUMBER FORMAT");
					}						 								     								
				}while(!validage);				
				System.out.println("ENTER CUSTOMER ADDR");
				String addr = new String();
				System.out.println("ENTER HOUSE NO");
				String addr1 =sc.next();
				System.out.println("ENTER STREET NAME");
				String addr2 = sc.next();
				System.out.println("ENTER CITY NAME");
				String addr3 = sc.next();
				System.out.println("ENTER STATE NAME");
				String addr4 =sc.next();
				System.out.println("ENTER PINCODE");
				String addr5 = sc.next();
				addr=addr1+","+addr2+","+addr3+","+addr4+","+addr5;
				bean.setAddr(addr);
				System.out.println("ENTER BALANCE"); 
				double amt = sc.nextInt();				
				if(((amt>=0)))
				{	
					bean.setAmt(amt);	 
					boolean isAdded;
					try {
						isAdded = service.addCustomer(bean);
						if (validname && validphno && isAdded && validage && validpan) 
						{
							System.out.println("added successfully");
							System.out.println(bean);
						} else
							System.out.println("not added");

					} catch (CustomerNotFoundException e) {
						System.out.println(e.getMessage());
					}

				}else
				{	
					try {
						throw new CustomerNotFoundException("PLEASE ENTER MINIMUM BALANCE");
					} catch (CustomerNotFoundException e) {
						System.out.println(e.getMessage());
					}										
				}					
				break;
			case 2:
				boolean validacc=false;
				boolean validpin=false;
				int accno1=0;
				System.out.println("ENTER ACCNO TO GET BALANCE");
				do{
					Scanner sc2 = new Scanner(System.in);					
					try{
					 accno1 = sc2.nextInt();
					 if(service.validateAccno(accno1))						
							validacc=true;					
				//	}	
					//catch(CustomerNotFoundException e)					
					else
					{
						System.out.println("NOT A VALID ACCOUNT NUMBER");
					}
					}catch(InputMismatchException e)
					{
						System.out.println("ENTER PROPER FORMAT");
					} 					
					/*else{	
						try {
							throw new CustomerNotFound("ENTER VALID ACCOUNT");
						}
							catch (CustomerNotFound e) {
								System.out.println(e.getMessage());
							}}*/				
				}while(!validacc);					
						do{
							System.out.println("ENTER PIN");
							int pin1=sc.nextInt();
							boolean validpinno = service.validatePinno(accno1,pin1);
							if(validpinno)
							{	validpin=true;								
							try {
								double c = service.displayCustomer(accno1,pin1);
								System.out.println(c);
							} 
							catch (CustomerNotFoundException e) {
							  System.out.println("ENTER A VALID ACCOUNT NUMBER"+e.getMessage());
							}/*catch(InputMismatchException e)
							{
								System.out.println("ENTER PROPER FORMAT"+e.getMessage());
							}*/			                           
							}/*else
							{
								System.out.println("ENTER PROPER FORMAT");
							}
							*/
						}	while(!validpin);
					
						/*
						catch(NullPointerException e)
						{
							System.out.println("ENTER VALID ACCOUNT NUMBER"+e.getMessage());
						}*/
					//}
				//}
				break;							
			case 3: 
				System.out.println("ENTER ACCNO TO DEPOSIT");
				int accno2 = sc.nextInt();				
				if (service.validateAccno(accno2))
				{
					System.out.println("ENTER PIN");
					int pin2=sc.nextInt();
					boolean validpinno1 = service.validatePinno(accno2,pin2);
					if(validpinno1)
					{	System.out.println("----------DEPOSIT--------------");
					System.out.println("ENTER AMOUNT TO DEPOSIT");
					int da = sc.nextInt();
					Customer c=service.displayCust(accno2);	
					double b=c.getAmt();
					double a= service.depositAmt(da,c,accno2,pin2);	
					if(a>b){
						System.out.println("DEPOSITED DONE SUCCESSFULLY");
						System.out.println("UPDATED BALANCE: "+a);
						break;
					}else {
						System.out.println("DEPOSIT FAILED");
					}
					}
					else
						System.out.println("PLEASE ENTER CORRECT PIN");
				}
				else
				{
					try {
						throw new CustomerNotFoundException("ENTER VALID ACCOUNT");
					} catch (CustomerNotFoundException e) {
						System.out.println(e.getMessage());	
					}
				}
				break;
			case 4:
				System.out.println("ENTER ACCNO TO WITHDRAW");
				int accno3 = sc.nextInt();							
				boolean validaccno2 = service.validateAccno(accno3);
				if (validaccno2) {	
					System.out.println("ENTER PIN");
					int pin3=sc.nextInt();
					boolean validpinno2 = service.validatePinno(accno3,pin3);
					if(validpinno2)
					{	Customer c=service.displayCust(accno3);
					if(c.getAccno()==accno3 && c.getPin()==pin3)
					{
						System.out.println("------------WITHDRAW--------------");
					System.out.println("ENTER AMOUNT TO WITHDRAW");
					int wd = sc.nextInt();
					double at=c.getAmt();
					double a = service.withDraw(c,wd);				
					if(a<at)
					{
						System.out.println("WITHDRAW DONE SUCCESSFULLY");
						System.out.println("BALANCE:"+a);
					}
					else
						System.out.println("WITHDRAW FAILED");
					}else
						System.out.println("ENTER VALID PIN FOR YOUR ACCOUNT");
					}else
						System.out.println("VALID PIN");
				}
				else
				{
					try {
						throw new CustomerNotFoundException("ENTER VALID ACCOUNT");
					} catch (CustomerNotFoundException e) {
						System.out.println(e.getMessage());
					}		}

				break; 
			case 5:System.out.println("ENTER YOUR ACCOUNT NUMBER");			  
			int accno4 = sc.nextInt();		
			boolean validaccno3 = service.validateAccno(accno4);
			Customer c = service.displayCust(accno4);
			if(validaccno3)
			{		
				System.out.println("ENTER PIN");
				int pin4=sc.nextInt();
				boolean validpinno = service.validatePinno(accno4,pin4);
				if((c.getAccno()==accno4)&&(c.getPin()==pin4))
				{				
					System.out.println("ENTER  ACCOUNT NUMBER TO TRANSFER");				  
					int accno5 = sc.nextInt();	
					if(validpinno)
					{
						boolean validaccno4 = service.validateAccno(accno5);
						if (validaccno4) {			
							System.out.println("ENTER AMOUNT TO TRANSFER");
							double at = sc.nextInt();	
							Customer b=service.displayCust(accno5);

							boolean z=service.fundTransfer(c, b, at, accno4, accno5, pin4);			
							if(z){						 

								System.out.println("TRANSACTION DONE SUCCESSFUL");
								System.out.println("BALANCE IN YOUR ACCOUNT: "+c.getAmt());
								System.out.println("BALANCE IN OTHER ACCOUNT: "+b.getAmt());										
							}else{
								System.out.println("TRANSACTION FAILED");}


						}else{
							try {
								throw new CustomerNotFoundException("ENTER VALID ACCOUNT OF OTHERS TO TRANSFER");
							} catch (CustomerNotFoundException e) {
								System.out.println(e.getMessage());
							}
						}
					}	
				}else{
					try {
						throw new CustomerNotFoundException("ENTER VALID PIN FOR YOUR ACCOUNT");
					} catch (CustomerNotFoundException e) {
						// TODO: handle exception
						System.out.println(e.getMessage());
					}
				}
			}else{
				try {
					throw new CustomerNotFoundException("YOUR ACCOUNT NUMBER IS NOT CORRECT");
				} catch (CustomerNotFoundException e) {
					// TODO: handle exception
					System.out.println(e.getMessage());
				}	
			}
			break;
			case 6:
				System.out.println("---------PRINT TRANSACTIONS-----------");
				System.out.println("ENTER YOUR ACCOUNT NUMBER");			  
				int accno6 = sc.nextInt();			
				if(accno6!=0)
				{
					boolean validaccno5 = service.validateAccno(accno6);				
					System.out.println("ENTER PIN");
					int pin5=sc.nextInt();
					boolean validpinno5 = service.validatePinno(accno6,pin5);
					Customer c1 = service.displayCust(accno6);
					if((c1.getAccno()==accno6)&&(c1.getPin()==pin5))
					{									
						List<Transaction> list=service.printTransactions(accno6, pin5);
						if(list==null){
							System.out.println("PLEASE ENTER CORRECT ACCOUNT NUMBER AND PIN");
						}else{
							Transaction a=new Transaction();					
							Iterator<Transaction> iterator = list.iterator();
							try
							{
							System.out.println(iterator.next());
							}catch(NoSuchElementException e)
							{
							System.out.println("NO TRANSACTIONS DONE TILL NOW");	
						//	System.out.println("          CURRENT BALANCE: "+c1.getAmt());
							}
							while(iterator.hasNext()){
								System.out.println(iterator.next());
							}
							System.out.println("------------------------------------------");
							System.out.println("          CURRENT BALANCE      "+c1.getAmt());
						}
					}else {
						System.err.println("PLEASE ENTER VALID PIN");
					}
				}
				else {
					try {
						throw new CustomerNotFoundException("PLEASE ENTER VALID ACCOUNT NUMBER");
					} catch (CustomerNotFoundException e) {
						System.out.println(e.getMessage());
					}
				}
				break; 
			case 7: System.exit(0);
			break;	
			default:
				break;
			}

		}

	}
}
